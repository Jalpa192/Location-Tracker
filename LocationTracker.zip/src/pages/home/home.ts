import { LocationObj } from './../../interface/locationObj.interface';
import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController } from 'ionic-angular';
import { FbLocationProvider } from '../../providers/fb-location/fb-location';
import { Observable } from 'rxjs/Observable';


declare var google;

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  locationList: LocationObj[];
  //locationList: LocationObj;
  //locationList: Observable<LocationObj[]>;
  //locationList2: LocationObj[] = [];


  @ViewChild('map') mapElement: ElementRef;
  map: any;
  geocoder = new google.maps.Geocoder;

  constructor(public navCtrl: NavController, private fblocation: FbLocationProvider) {
    // this.GetLocations();
  }

  ionViewDidLoad() {
    this.GetLocations();
    console.log(google);
  }

  GetLocations() {
    //this.locationList = this.fblocation.getLocationList();
    // console.log("getLocationList 0");
    // this.fblocation.getLocationList().subscribe(res => {
    //   console.log("getLocationList 2");
    //   res.map(data => {
    //     let location = data.payload.val();
    //     location.key = data.key;
    //     this.locationList2.push(location);
    //   });
    // })

    this.fblocation.getLocationList().subscribe(res => {
      this.locationList = res;
      this.locationList.forEach(element => {
        this.geocodeLatLng(element);
      });
      console.log("list", this.locationList);

      if (this.map == undefined || this.map == null) {
        this.loadMap(this.locationList[0]);
      }
    });

  }

  loadMap(locationObj: LocationObj) {
    let latLng = new google.maps.LatLng(locationObj.latitude, locationObj.longitude);
    let mapOptions = {
      center: latLng,
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
  }

  showlocationOnMap(locationObj: LocationObj) {
    console.log("showlocationOnMap", locationObj);
    let marker = new google.maps.Marker({
      map: this.map,
      animation: google.maps.Animation.DROP,
      position: { lat: locationObj.latitude, lng: locationObj.longitude }
    });
    console.log("showlocationOnMap marker",marker);
    let content = "<h4>Information!</h4> <p>" + locationObj.userName + "</p>";
    this.addInfoWindow(marker, content);
  }

  addInfoWindow(marker, content) {

    let infoWindow = new google.maps.InfoWindow({
      content: content
    });

    google.maps.event.addListener(marker, 'click', () => {
      infoWindow.open(this.map, marker);
    });

  }

  geocodeLatLng(location: LocationObj) {

    var latlng = { lat: location.latitude, lng: location.longitude };
    this.geocoder.geocode({ 'location': latlng }, function (results, status) {
      if (status === 'OK') {
        if (results[0]) {
          location.Address = results[0].formatted_address

          // this.map.setZoom(11);
          // var marker = new google.maps.Marker({
          //   position: latlng,
          //   map: this.map
          // });
          // this.addInfoWindow(marker, results[0].formatted_address);
        } else {
          console.log('No results found');
        }
      } else {
        console.log('Geocoder failed due to: ' + status);
      }
    });
  }

}
