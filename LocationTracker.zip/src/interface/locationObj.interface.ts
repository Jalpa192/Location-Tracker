export interface LocationObj {
    key? : string,
    deviceId: string,
    latitude: number,
    longitude: number,
    userName?: string,
    Address? : string
}