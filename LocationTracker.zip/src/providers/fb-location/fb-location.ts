import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { LocationObj } from '../../interface/locationObj.interface';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class FbLocationProvider {

  private fblocationObj: string = 'MyLocation';
  private noteListRef = this.db.list<LocationObj>(this.fblocationObj);

  constructor(public db: AngularFireDatabase) {

  }

  saveLocation(location: LocationObj) {
    return this.noteListRef.push(location);
  }

  updateLocation(location: LocationObj) {
    return this.noteListRef.update(location.key, location);
  }

  getLocationList(): Observable<LocationObj[]> {
    return this.noteListRef.snapshotChanges().pipe(
      map(res => {
        return res.map(a => {
          let data: any = a.payload.toJSON();
          let obj: LocationObj = {
            key: a.key,
            deviceId: data.deviceId,
            latitude: data.latitude,
            longitude: data.longitude,
            userName: data.userName
          }
          return obj;
        });
      })
    );
  }

  HasDevice(deviceId: string) {
    return this.db.list<LocationObj>(this.fblocationObj, ref => ref.orderByChild('deviceId').equalTo(deviceId));
  }
}
