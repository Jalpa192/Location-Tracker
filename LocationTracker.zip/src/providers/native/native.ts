import { Injectable } from '@angular/core';
import { Geolocation } from '@ionic-native/geolocation';
import { Device } from '@ionic-native/Device';
import { FbLocationProvider } from '../fb-location/fb-location';
import { LocationObj } from '../../interface/locationObj.interface';


@Injectable()
export class NativeProvider {

  locationKey: any;
  private UserLocationObj: LocationObj;

  constructor(private geolocation: Geolocation, private device: Device, private fblocation: FbLocationProvider) {
  }


  GetAndWatchDeviceLocation() {

    let deviceId = this.device.uuid == null ? "uuid" : this.device.uuid;

    this.geolocation.getCurrentPosition().then((resp) => {
      // resp.coords.latitude
      // resp.coords.longitude

      //console.log("getCurrentPosition", resp.coords.latitude, resp.coords.longitude);
      // let lobj: LocationObj = {
      //   deviceId: deviceId,
      //   latitude: resp.coords.latitude,
      //   longitude: resp.coords.longitude
      // }
      // this.fblocation.saveLocation(lobj).then(ref => {
      //   console.log("saveLocation", lobj, ref);
      //   this.locationKey = ref.key;
      // });
    }).catch((error) => {
      console.log('Error getting location', error);
    });

    let watch = this.geolocation.watchPosition();

    watch.subscribe((resp) => {
      //console.log("watch", resp.coords.latitude, resp.coords.longitude);

      let lobj: LocationObj = {
        key: deviceId,
        deviceId: deviceId,
        latitude: resp.coords.latitude,
        longitude: resp.coords.longitude,
        userName : 'jalpa'
      }
      this.fblocation.updateLocation(lobj).then(ref => {
        //console.log("updateLocation", lobj);
        this.UserLocationObj = lobj;
      });

      // data can be a set of coordinates, or an error (if an error occurred).
      // data.coords.latitude
      // data.coords.longitude
    });
  }

  GetMyLocation(): LocationObj {
    return this.UserLocationObj;
  }
}
